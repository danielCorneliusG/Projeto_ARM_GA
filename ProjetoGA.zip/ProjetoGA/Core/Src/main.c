/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2026 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "i2c.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

#define VL53L0X_DEFAULT_ADDRESS     (0x29 << 1)
#define VL53L0X_CARRO_ADDRESS       (0x30 << 1)
#define VL53L0X_CANCELA_ADDRESS     (0x31 << 1)
#define DISTANCIA_DETECCAO_MM       800
#define TEMPO_CONFIRMAR_VAGA        5000
#define TEMPO_FECHAR_CANCELA        2000

#define SERVO_CHANNEL               TIM_CHANNEL_1

#define SERVO_FECHADO               1000
#define SERVO_ABERTO                2000

#define VL53L0X_REG_SYSRANGE_START                  0x00
#define VL53L0X_REG_SYSTEM_SEQUENCE_CONFIG          0x01
#define VL53L0X_REG_SYSTEM_INTERMEASUREMENT_PERIOD  0x04

#define VL53L0X_REG_SYSTEM_INTERRUPT_CONFIG_GPIO    0x0A
#define VL53L0X_REG_GPIO_HV_MUX_ACTIVE_HIGH         0x84
#define VL53L0X_REG_SYSTEM_INTERRUPT_CLEAR          0x0B

#define VL53L0X_REG_RESULT_INTERRUPT_STATUS         0x13
#define VL53L0X_REG_RESULT_RANGE_STATUS              0x14

#define VL53L0X_REG_I2C_SLAVE_DEVICE_ADDRESS        0x8A

#define VL53L0X_REG_IDENTIFICATION_MODEL_ID         0xC0

#define VL53L0X_STATUS_OK             0
#define VL53L0X_STATUS_ERROR          1


/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

//0 = livre
uint8_t vagaOcupada = 0;
uint32_t inicioDeteccaoVaga = 0;
uint8_t contandoOcupacao = 0;
uint32_t inicioAusenciaVaga = 0;
uint8_t contandoLiberacao = 0;

//0 = fechada
uint8_t cancelaAberta = 0;
uint32_t inicioFechamentoCancela = 0;
uint8_t contandoFechamentoCancela = 0;

uint16_t distanciaCarro = 8191;
uint16_t distanciaCancela = 8191;
uint8_t sensoresInicializados = 0;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);

/* USER CODE BEGIN PFP */

// VL53L0X
HAL_StatusTypeDef VL53_WriteByte(
    uint16_t endereco,
    uint8_t reg,
    uint8_t valor
);

HAL_StatusTypeDef VL53_ReadByte(
    uint16_t endereco,
    uint8_t reg,
    uint8_t *valor
);

HAL_StatusTypeDef VL53_ReadMulti(
    uint16_t endereco,
    uint8_t reg,
    uint8_t *dados,
    uint16_t tamanho
);

uint8_t VL53_Init(
    uint16_t endereco
);

uint8_t VL53_SetAddress(
    uint16_t enderecoAntigo,
    uint16_t enderecoNovo
);

uint8_t VL53_ReadDistance(
    uint16_t endereco,
    uint16_t *distancia
);



void InicializarSensores(void);
void AtualizarVaga(void);
void AtualizarLEDs(void);
void AtualizarCancela(void);
void Servo_Abrir(void);
void Servo_Fechar(void);


/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

HAL_StatusTypeDef VL53_WriteByte(
    uint16_t endereco,
    uint8_t reg,
    uint8_t valor
)
{
    uint8_t dados[2];

    dados[0] = reg;
    dados[1] = valor;

    return HAL_I2C_Master_Transmit(
        &hi2c1,
        endereco,
        dados,
        2,
        100
    );
}

HAL_StatusTypeDef VL53_ReadByte(
    uint16_t endereco,
    uint8_t reg,
    uint8_t *valor
)
{
    HAL_StatusTypeDef status;

    status = HAL_I2C_Master_Transmit(
        &hi2c1,
        endereco,
        &reg,
        1,
        100
    );

    if (status != HAL_OK)
    {
        return status;
    }

    return HAL_I2C_Master_Receive(
        &hi2c1,
        endereco,
        valor,
        1,
        100
    );
}

HAL_StatusTypeDef VL53_ReadMulti(
    uint16_t endereco,
    uint8_t reg,
    uint8_t *dados,
    uint16_t tamanho
)
{
    HAL_StatusTypeDef status;

    status = HAL_I2C_Master_Transmit(
        &hi2c1,
        endereco,
        &reg,
        1,
        100
    );

    if (status != HAL_OK)
    {
        return status;
    }

    return HAL_I2C_Master_Receive(
        &hi2c1,
        endereco,
        dados,
        tamanho,
        100
    );
}


uint8_t VL53_Init(
    uint16_t endereco
)
{
    uint8_t id;
    uint8_t valor;

    if (HAL_I2C_IsDeviceReady(
            &hi2c1,
            endereco,
            3,
            100) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (VL53_ReadByte(
            endereco,
            VL53L0X_REG_IDENTIFICATION_MODEL_ID,
            &id) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (id != 0xEE)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_SYSTEM_INTERRUPT_CONFIG_GPIO,
            0x04) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }


    if (VL53_ReadByte(
            endereco,
            VL53L0X_REG_GPIO_HV_MUX_ACTIVE_HIGH,
            &valor) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    valor &= ~0x10;

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_GPIO_HV_MUX_ACTIVE_HIGH,
            valor) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_SYSTEM_INTERRUPT_CLEAR,
            0x01) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_SYSTEM_SEQUENCE_CONFIG,
            0xFF) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_SYSRANGE_START,
            0x00) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }


    return VL53L0X_STATUS_OK;
}

uint8_t VL53_SetAddress(
    uint16_t enderecoAntigo,
    uint16_t enderecoNovo
)
{
    if (VL53_WriteByte(
            enderecoAntigo,
            VL53L0X_REG_I2C_SLAVE_DEVICE_ADDRESS,
            (uint8_t)(enderecoNovo >> 1)) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }


    HAL_Delay(5);

    return VL53L0X_STATUS_OK;
}

uint8_t VL53_ReadDistance(
    uint16_t endereco,
    uint16_t *distancia
)
{
    uint8_t status;
    uint8_t dados[2];

    if (VL53_WriteByte(
            endereco,
            VL53L0X_REG_SYSRANGE_START,
            0x01) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }


    // Esperar medição terminar.
    uint32_t inicio = HAL_GetTick();

    while (1)
    {
        if (VL53_ReadByte(
                endereco,
                VL53L0X_REG_RESULT_INTERRUPT_STATUS,
                &status) != HAL_OK)
        {
            return VL53L0X_STATUS_ERROR;
        }


        if ((status & 0x07) != 0)
        {
            break;
        }


        if ((HAL_GetTick() - inicio) > 100)
        {
            return VL53L0X_STATUS_ERROR;
        }


        HAL_Delay(1);
    }


    if (VL53_ReadMulti(
            endereco,
            VL53L0X_REG_RESULT_RANGE_STATUS + 10,
            dados,
            2) != HAL_OK)
    {
        return VL53L0X_STATUS_ERROR;
    }


    *distancia =
        ((uint16_t)dados[0] << 8) |
        dados[1];


    VL53_WriteByte(
        endereco,
        VL53L0X_REG_SYSTEM_INTERRUPT_CLEAR,
        0x01
    );


    return VL53L0X_STATUS_OK;
}


void InicializarSensores(void)
{
    HAL_GPIO_WritePin(
        XSHUT_Carro_GPIO_Port,
        XSHUT_Carro_Pin,
        GPIO_PIN_RESET
    );

    HAL_GPIO_WritePin(
        XSHUT_Cancela_GPIO_Port,
        XSHUT_Cancela_Pin,
        GPIO_PIN_RESET
    );

    HAL_Delay(10);

    HAL_GPIO_WritePin(
        XSHUT_Carro_GPIO_Port,
        XSHUT_Carro_Pin,
        GPIO_PIN_SET
    );

    HAL_Delay(10);

    if (VL53_Init(VL53L0X_DEFAULT_ADDRESS)
            != VL53L0X_STATUS_OK)
    {
        sensoresInicializados = 0;
        return;
    }

    if (VL53_SetAddress(
            VL53L0X_DEFAULT_ADDRESS,
            VL53L0X_CARRO_ADDRESS)
            != VL53L0X_STATUS_OK)
    {
        sensoresInicializados = 0;
        return;
    }

    HAL_GPIO_WritePin(
        XSHUT_Cancela_GPIO_Port,
        XSHUT_Cancela_Pin,
        GPIO_PIN_SET
    );

    HAL_Delay(10);

    if (VL53_Init(VL53L0X_DEFAULT_ADDRESS)
            != VL53L0X_STATUS_OK)
    {
        sensoresInicializados = 0;
        return;
    }

    if (VL53_SetAddress(
            VL53L0X_DEFAULT_ADDRESS,
            VL53L0X_CANCELA_ADDRESS)
            != VL53L0X_STATUS_OK)
    {
        sensoresInicializados = 0;
        return;
    }


    sensoresInicializados = 1;
}


void Servo_Abrir(void)
{
    __HAL_TIM_SET_COMPARE(
        &htim1,
        SERVO_CHANNEL,
        SERVO_ABERTO
    );

    cancelaAberta = 1;
}

void Servo_Fechar(void)
{
    __HAL_TIM_SET_COMPARE(
        &htim1,
        SERVO_CHANNEL,
        SERVO_FECHADO
    );

    cancelaAberta = 0;

    contandoFechamentoCancela = 0;
}


void AtualizarVaga(void)
{
    uint8_t leituraOK;

    leituraOK = VL53_ReadDistance(
        VL53L0X_CARRO_ADDRESS,
        &distanciaCarro
    );

    if (leituraOK != VL53L0X_STATUS_OK)
    {
        return;
    }

    if (distanciaCarro <= DISTANCIA_DETECCAO_MM)
    {
        contandoLiberacao = 0;

        if (vagaOcupada == 0)
        {
            if (contandoOcupacao == 0)
            {
                inicioDeteccaoVaga = HAL_GetTick();

                contandoOcupacao = 1;
            }

            if ((HAL_GetTick() - inicioDeteccaoVaga)
                    >= TEMPO_CONFIRMAR_VAGA)
            {
                vagaOcupada = 1;
                contandoOcupacao = 0;
            }
        }
    }

    else
    {
        contandoOcupacao = 0;
        if (vagaOcupada == 1)
        {
            if (contandoLiberacao == 0)
            {
                inicioAusenciaVaga = HAL_GetTick();

                contandoLiberacao = 1;
            }

            if ((HAL_GetTick() - inicioAusenciaVaga)
                    >= TEMPO_CONFIRMAR_VAGA)
            {
                vagaOcupada = 0;

                contandoLiberacao = 0;
            }
        }
    }
}


void AtualizarLEDs(void)
{
    if (vagaOcupada)
    {
        HAL_GPIO_WritePin(
            LED_Carro_GPIO_Port,
            LED_Carro_Pin,
            GPIO_PIN_SET
        );
    }
    else
    {
        HAL_GPIO_WritePin(
            LED_Carro_GPIO_Port,
            LED_Carro_Pin,
            GPIO_PIN_RESET
        );
    }

    if (cancelaAberta)
    {
        HAL_GPIO_WritePin(
            LED_Cancela_GPIO_Port,
            LED_Cancela_Pin,
            GPIO_PIN_SET
        );
    }
    else
    {
        HAL_GPIO_WritePin(
            LED_Cancela_GPIO_Port,
            LED_Cancela_Pin,
            GPIO_PIN_RESET
        );
    }
}


void AtualizarCancela(void)
{
    uint8_t leituraOK;

    leituraOK = VL53_ReadDistance(
        VL53L0X_CANCELA_ADDRESS,
        &distanciaCancela
    );

    if (leituraOK != VL53L0X_STATUS_OK)
    {
        return;
    }


    if (distanciaCancela <= DISTANCIA_DETECCAO_MM)
    {
        contandoFechamentoCancela = 0;

        if (vagaOcupada == 0)
        {
            if (!cancelaAberta)
            {
                Servo_Abrir();
            }
        }

        return;
    }


    if (cancelaAberta)
    {
        if (contandoFechamentoCancela == 0)
        {
            inicioFechamentoCancela = HAL_GetTick();

            contandoFechamentoCancela = 1;
        }

        if ((HAL_GetTick() - inicioFechamentoCancela)
                >= TEMPO_FECHAR_CANCELA)
        {
            Servo_Fechar();
        }
    }
}


/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */


  /* MCU Configuration--------------------------------------------------------*/

  HAL_Init();


  /* USER CODE BEGIN Init */

  /* USER CODE END Init */


  /* Configure the system clock */
  SystemClock_Config();


  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */


  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_I2C1_Init();
  MX_TIM1_Init();


  /* USER CODE BEGIN 2 */
  HAL_TIM_PWM_Start(
      &htim1,
      SERVO_CHANNEL
  );

  InicializarSensores();
  Servo_Fechar();
  AtualizarLEDs();

  /* USER CODE END 2 */


  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    if (sensoresInicializados)
        AtualizarVaga();
        AtualizarLEDs();
        AtualizarCancela();
    }

    HAL_Delay(20);


    /* USER CODE BEGIN 3 */
  }

  /* USER CODE END 3 */
}


/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInit = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL16;

  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType =
      RCC_CLOCKTYPE_HCLK |
      RCC_CLOCKTYPE_SYSCLK |
      RCC_CLOCKTYPE_PCLK1 |
      RCC_CLOCKTYPE_PCLK2;

  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(
          &RCC_ClkInitStruct,
          FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }

  PeriphClkInit.PeriphClockSelection = RCC_PERIPHCLK_I2C1;

  PeriphClkInit.I2c1ClockSelection =
      RCC_I2C1CLKSOURCE_HSI;

  if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInit) != HAL_OK)
  {
    Error_Handler();
  }
}


/* USER CODE BEGIN 4 */

/* USER CODE END 4 */


/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */

  __disable_irq();

  while (1)
  {
  }

  /* USER CODE END Error_Handler_Debug */
}


#ifdef USE_FULL_ASSERT

/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */

  /* USER CODE END 6 */
}

#endif /* USE_FULL_ASSERT */